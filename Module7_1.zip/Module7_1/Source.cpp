/****************************************************************************************
* Dallas Weber
* CS-330-T5525 Comp Graphic and Visualization 23EW5
* June 18th, 2023
* Professor Dr. Kurt Diesch
* 7-1: Project
*
* Code References:
* Title: Learn OpenGL (Tutorial)
* Author: Joey de Vries (https://twitter.com/JoeyDeVriez)
* Availability: https://learnopengl.com/
* License: https://creativecommons.org/licenses/by/4.0/legalcode
*
* Title: Modules 3-6 Tutorials
* Contributors: hallettsnhu (https://github.com/hallettsnhu), SamanthaChapmanSNHU (https://github.com/SamanthaChapmanSNHU),
* dazotaro Jorge Usabiaga (https://github.com/dazotaro)
* Availability: https://github.com/SNHU-CS/CS-330/blob/master/module02/mod2_tutorials.md
*
****************************************************************************************/

#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
// Image loading Utility functions

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <GL/gl.h>

#include <camera.h>

using namespace std; // Uses the standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "Project: 7-1"; // Macro for window title

    // Variables for window width, height and perspective
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;
    bool isPerspective = true; // By default, perspective view is enabled

    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        GLuint vao;         // Handle for the vertex array object
        GLuint vbos[2];     // Handles for the vertex buffer objects
        GLuint nIndices;    // Number of indices of the mesh
    };

    // Function to create main window
    GLFWwindow* gWindow = nullptr;

    // Triangle mesh data
    GLMesh gMeshBook1;
    GLMesh gMeshPlane;
    GLMesh gMeshCylinder;

    // Texture id
    GLuint gTextureBook1;
    GLuint gTexturePlane;
    GLuint gTextureCylinder;
    GLuint gTextureLayer;


    // Shader program
    GLuint gProgramId;

    // Camera
    Camera gCamera(glm::vec3(0.0f, 0.0f, 5.0f));
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    // Timing
    float gDeltaTime = 0.0f; // Time between current frame and last frame
    float gLastFrame = 0.0f;
}

/* User-defined Function prototypes to:
* initialize the program, set the window size,
* redraw graphics on the window when resized,
* and render graphics on the screen
*/
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreateMeshBook1(GLMesh& mesh);
void UCreateMeshCylinder(GLMesh& mesh);
void UCreateMeshPlane(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);


// Vertex Shader Program Source Code
const GLchar* vertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position;   // Vertex position from VBO
    layout(location = 1) in vec3 color;      // Vertex color from VBO
    layout(location = 2) in vec2 texUV;      // Texture UV from VBO
    layout(location = 3) in vec3 normal;     // Normal from VBO

    uniform mat4 model;       // Model matrix
    uniform mat4 view;        // View matrix
    uniform mat4 projection;  // Projection matrix
    uniform vec3 lightPos;    // Light position

    out vec3 FragPos;     // Fragment Position
    out vec3 Normal;      // Normal for lighting calculation
    out vec3 LightPos;    // Light position for lighting calculation
    out vec3 VertexColor; // Vertex color for fragment shader
    out vec2 TextureUV;   // Texture UV for fragment shader

    void main()
    {
        gl_Position = projection * view * model * vec4(position, 1.0f);
        FragPos = vec3(model * vec4(position, 1.0f));
        Normal = mat3(transpose(inverse(model))) * normal;
        LightPos = lightPos;
        VertexColor = color;
        TextureUV = texUV;
    }
);

// Fragment Shader Program Source Code
const GLchar* fragmentShaderSource = GLSL(440,
    in vec3 FragPos;
    in vec3 Normal;
    in vec3 LightPos;
    in vec3 VertexColor;
    in vec2 TextureUV;

    out vec4 fragmentColor;

    uniform sampler2D uTextureBook;
    uniform sampler2D uTexturePlane;
    uniform sampler2D uTextureCylinder;
    uniform sampler2D uTextureLayer;  // New uniform for the overlay texture
    uniform int isBook;
    uniform int isLayer;  // New uniform to determine if the layer is active
    uniform int isCylinder;

    void main()
    {
        vec3 lightColor = vec3(1.0f, 1.0f, 1.0f);
        vec3 objectColor = vec3(1.0f, 1.0f, 1.0f);
        float ambientStrength = 0.9f;
        vec3 ambient = ambientStrength * lightColor;

        // Diffuse
        vec3 norm = normalize(Normal);
        vec3 lightDir = normalize(LightPos - FragPos);
        float diff = max(dot(norm, lightDir), 0.0);
        vec3 diffuse = diff * lightColor;

        vec3 result = (ambient + diffuse) * objectColor;
        vec4 textureColor = vec4(1.0f, 1.0f, 1.0f, 1.0f);

        if (isBook == 1)
            textureColor = texture(uTextureBook, TextureUV);
        else if (isCylinder == 1)
            textureColor = texture(uTextureCylinder, TextureUV);
        else
            textureColor = texture(uTexturePlane, TextureUV);

        fragmentColor = textureColor * vec4(result, 1.0f);
    }
);

// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}

// Global light properties
glm::vec3 lightPos(1.2f, 1.0f, 2.0f); // position of the light source
glm::vec3 lightColor(1.0f, 1.0f, 1.0f); // white light

// Main function. Entry point to the OpenGL program
int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Enable blending
    glEnable(GL_BLEND);
    // Set blending function
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    // Create the mesh
    UCreateMeshBook1(gMeshBook1); // Calls the function to create the Vertex Buffer Object

    // Creates an OpenGL shader program
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return EXIT_FAILURE;

    // Load texture (relative to project's directory)
    const char* texFilename = "images/book1.png";
    if (!UCreateTexture(texFilename, gTextureBook1))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    // Create the mesh for the plane
    UCreateMeshPlane(gMeshPlane); // Calls the function to create the Vertex Buffer Object

    // Load texture for the plane
    const char* texPlaneFilename = "images/desk.png"; // replace with your plane texture
    if (!UCreateTexture(texPlaneFilename, gTexturePlane))
    {
        cout << "Failed to load texture " << texPlaneFilename << endl;
        return EXIT_FAILURE;
    }

    // Creates an OpenGL shader program
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return EXIT_FAILURE;

    // Load texture (relative to project's directory)
    const char* texLayerFilename = "images/layer.png";
    if (!UCreateTexture(texLayerFilename, gTextureLayer))
    {
        cout << "Failed to load texture " << texLayerFilename << endl;
        return EXIT_FAILURE;
    }

    // Create the mesh
    UCreateMeshCylinder(gMeshCylinder); // Calls the function to create the Vertex Buffer Object

    // Creates an OpenGL shader program
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return EXIT_FAILURE;

    // Load texture (relative to project's directory)
    const char* texCylinderFilename = "images/slice.jpg";
    if (!UCreateTexture(texCylinderFilename, gTextureCylinder))
    {
        cout << "Failed to load texture " << texCylinderFilename << endl;
        return EXIT_FAILURE;
    }

    glUseProgram(gProgramId);
    // We set the uTextureBook as texture unit 0
    glUniform1i(glGetUniformLocation(gProgramId, "uTextureBook"), 0);
    // We set the uTexturePlane as texture unit 1
    glUniform1i(glGetUniformLocation(gProgramId, "uTexturePlane"), 1);
    // We set the uTexturePlane as texture unit 1
    glUniform1i(glGetUniformLocation(gProgramId, "uTextureLayer"), 2);
    // We set the uTexturePlane as texture unit 1
    glUniform1i(glGetUniformLocation(gProgramId, "uTextureCylinder"), 3);

    // Sets the background color of the window to black (it will be implicitely used by glClear)
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // Render loop
    while (!glfwWindowShouldClose(gWindow)) {

        // Timing each frame
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;
        UProcessInput(gWindow); // Input
        URender(); // Render this frame
        glfwPollEvents();
    }

    // Release mesh data
    UDestroyMesh(gMeshBook1);
    UDestroyMesh(gMeshPlane);
    UDestroyMesh(gMeshCylinder);

    // Release texture
    UDestroyTexture(gTextureBook1);
    UDestroyTexture(gTexturePlane);
    UDestroyTexture(gTextureLayer);
    UDestroyTexture(gTextureCylinder);

    // Release shader program
    UDestroyShaderProgram(gProgramId);

    // Terminate program
    exit(EXIT_SUCCESS);
}


// Initializes GLFW and GLEW and creates a window object
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }

    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // Mouse capture
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}

// A global flag to track the visibility state of the layer.
bool isLayerVisible = false;

void UProcessInput(GLFWwindow* window) {
    static const float cameraSpeed = 2.5f;
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
        isPerspective = !isPerspective; // Switch between perspective and orthographic view
    if (glfwGetKey(window, GLFW_KEY_H) == GLFW_PRESS)
        isLayerVisible = !isLayerVisible; // Toggle the visibility of the layer
}

// Function that handles window resize events for a GLFW window
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

// glfw: On mouse move, this callback is called
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos) {
    if (gFirstMouse) {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }
    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // Reversed since y-coordinates go from bottom to top
    gLastX = xpos;
    gLastY = ypos;
    gCamera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: Scroll wheel detection, this callback is called
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset) {
    gCamera.ProcessMouseScroll(yoffset);
}

// glfw: Handle mouse button events
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods) {
    switch (button) {
    case GLFW_MOUSE_BUTTON_LEFT: {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
                               break;

    case GLFW_MOUSE_BUTTON_MIDDLE: {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
                                 break;

    case GLFW_MOUSE_BUTTON_RIGHT: {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }

                                break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}

// Function called to render a frame
void URender() {
    glEnable(GL_DEPTH_TEST); // Enable z-depth

    // Clear the frame and z buffers
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Scales the object by 1.5
    glm::mat4 scale = glm::scale(glm::vec3(1.5f, 1.5f, 1.5f));

    // Rotates shape by 20 degrees on the x axis
    glm::mat4 rotation = glm::rotate(glm::radians(20.0f), glm::vec3(3.0f, 2.0f, 1.0f));

    // Place object at the origin
    glm::mat4 translation = glm::translate(glm::vec3(3.5f, .0f, 0.0f));

    glm::mat4 transformation(1.0f);

    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model = translation * rotation * scale;

    // Generate the view matrix
    glm::mat4 view = gCamera.GetViewMatrix(); // Camera, view transformation

    // Creates a projection
    glm::mat4 projection;
    if (isPerspective) {
        // Perspective view
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }
    else {
        // Orthographic view
        float aspectRatio = (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT;
        projection = glm::ortho(-aspectRatio, aspectRatio, -1.0f, 1.0f, -1.0f, 1.0f);
    }

    // Set the shader to be used
    glUseProgram(gProgramId);

    glUniformMatrix4fv(glGetUniformLocation(gProgramId, "model"), 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(glGetUniformLocation(gProgramId, "view"), 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(glGetUniformLocation(gProgramId, "projection"), 1, GL_FALSE, glm::value_ptr(projection));

    // Render the plane
    glUniform1i(glGetUniformLocation(gProgramId, "isBook"), 0);
    glBindVertexArray(gMeshPlane.vao);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gTexturePlane);
    glDrawElements(GL_TRIANGLES, gMeshPlane.nIndices, GL_UNSIGNED_SHORT, nullptr);


    // Render the layer, if 'H' was pressed
    if (isLayerVisible) {
        glUniform1i(glGetUniformLocation(gProgramId, "isLayer"), 1);
        glBindVertexArray(gMeshBook1.vao);
        glActiveTexture(GL_TEXTURE2);
        glBindTexture(GL_TEXTURE_2D, gTextureLayer);
        glDrawElements(GL_TRIANGLES, gMeshBook1.nIndices, GL_UNSIGNED_SHORT, nullptr);
    }

    // Render Book1
    glUniform1i(glGetUniformLocation(gProgramId, "isBook"), 1);
    glBindVertexArray(gMeshBook1.vao);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureBook1);
    glDrawElements(GL_TRIANGLES, gMeshBook1.nIndices, GL_UNSIGNED_SHORT, nullptr);

    // Render the Cylinder
    glUniform1i(glGetUniformLocation(gProgramId, "isBook"), 0);
    glUniform1i(glGetUniformLocation(gProgramId, "isCylinder"), 1); // Set isCylinder to 1 before drawing the cylinder
    glBindVertexArray(gMeshCylinder.vao);
    glActiveTexture(GL_TEXTURE3);
    glBindTexture(GL_TEXTURE_2D, gTextureCylinder); // binding the texture
    glDrawElements(GL_TRIANGLES, gMeshCylinder.nIndices, GL_UNSIGNED_SHORT, nullptr);
    glUniform1i(glGetUniformLocation(gProgramId, "isCylinder"), 0); // Reset isCylinder to 0 after drawing the cylinder


    // Unbind VAO
    glBindVertexArray(0);

    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow);
}

void UCreateMeshCylinder(GLMesh& mesh)
{
    const float radius = 0.20f;   // Radius of the cylinder
    const float height = 0.75f;   // Height of the cylinder
    const int numSegments = 30;  // Number of segments used to approximate the cylinder

    const int numVertices = numSegments * 2;  // Each segment has 2 vertices
    const int numIndices = numSegments * 6;   // Each segment has 2 triangles (6 indices)

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerColor = 4;
    const GLuint floatsPerUV = 2;  // New: texture coordinates (u, v)

    GLfloat* vertices = new GLfloat[numVertices * (floatsPerVertex + floatsPerColor + floatsPerUV)];  // 9 floats per vertex (3 position, 4 color, 2 texture coordinates)
    GLushort* indices = new GLushort[numIndices];

    // Generate the cylinder vertices
    for (int i = 0; i < numSegments; i++)
    {
        float angle = 2.0f * glm::pi<float>() * i / numSegments;
        float x = radius * cos(angle);
        float z = radius * sin(angle);
        float u = (float)i / numSegments;  // New: texture coordinate u

        // Top vertex
        vertices[i * 9] = x - 3.75f;
        vertices[i * 9 + 1] = height / 2.0f + 0.5f - 0.25f;  // Lowered y-coordinate by 0.25 units
        vertices[i * 9 + 2] = z + 0.5f;
        vertices[i * 9 + 3] = 1.0f;  // Red color component
        vertices[i * 9 + 4] = 0.0f;  // Green color component
        vertices[i * 9 + 5] = 0.0f;  // Blue color component
        vertices[i * 9 + 6] = 1.0f;  // Alpha color component
        vertices[i * 9 + 7] = u;  // Texture coordinate u
        vertices[i * 9 + 8] = 1.0f;  // Texture coordinate v (top of texture)

        // Bottom vertex
        vertices[(i + numSegments) * 9] = x - 3.75f;
        vertices[(i + numSegments) * 9 + 1] = -height / 2.0f + 0.5f - 0.25f;  // Lowered y-coordinate by 0.25 units
        vertices[(i + numSegments) * 9 + 2] = z + 0.5f;
        vertices[(i + numSegments) * 9 + 3] = 0.0f;  // Red color component
        vertices[(i + numSegments) * 9 + 4] = 1.0f;  // Green color component
        vertices[(i + numSegments) * 9 + 5] = 0.0f;  // Blue color component
        vertices[(i + numSegments) * 9 + 6] = 1.0f;  // Alpha color component
        vertices[(i + numSegments) * 9 + 7] = u;  // Texture coordinate u
        vertices[(i + numSegments) * 9 + 8] = 0.0f;  // Texture coordinate v (bottom of texture)
    }

    // Generate the cylinder indices
    for (int i = 0; i < numSegments; i++)
    {
        indices[i * 6] = i;
        indices[i * 6 + 1] = (i + 1) % numSegments;
        indices[i * 6 + 2] = i + numSegments;
        indices[i * 6 + 3] = i + numSegments;
        indices[i * 6 + 4] = (i + 1) % numSegments;
        indices[i * 6 + 5] = (i + 1) % numSegments + numSegments;
    }

    GLint stride = sizeof(GLfloat) * (floatsPerVertex + floatsPerColor + floatsPerUV);

    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);  // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, numVertices * (floatsPerVertex + floatsPerColor + floatsPerUV) * sizeof(GLfloat), vertices, GL_STATIC_DRAW);  // Sends vertex or coordinate data to the GPU

    mesh.nIndices = numIndices;
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, numIndices * sizeof(GLushort), indices, GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerColor, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(GLfloat) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    // New: Vertex Attribute Pointer for the texture coordinates
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(GLfloat) * (floatsPerVertex + floatsPerColor)));
    glEnableVertexAttribArray(2);

    delete[] vertices;
    delete[] indices;
};

// Implements the UCreateMesh function
void UCreateMeshBook1(GLMesh& mesh)
{
    // Position and Color data
    GLfloat verts[] = {
        // 1st rectangle (book) vertices, color values, and texture coordinates (indices 0-7)
        -0.25f,  0.125f, 0.0f,    0.0f, 1.0f, 0.0f, 1.0f,   0.0f, 1.0f,  // Top Right Vertex 0
        -0.25f, -0.125f, 0.0f,    1.0f, 1.0f, 0.0f, 0.0f,   0.0f, 0.666f, // Bottom Right Vertex 1
        -1.25f, -0.125f, 0.0f,    0.0f, 0.0f, 1.0f, 0.0f,   1.0f, 0.666f, // Bottom Left Vertex 2
        -1.25f,  0.125f, 0.0f,    1.0f, 0.0f, 0.0f, 1.0f,   1.0f, 1.0f,   // Top Left Vertex 3
        -0.25f, -0.125f, -1.0f,   1.0f, 1.0f, 1.0f, 1.0f,   0.0f, 0.666f, // Bottom Right Vertex 4
        -0.25f,  0.125f, -1.0f,   1.0f, 1.0f, 0.5f, 1.0f,   0.0f, 1.0f,   // Top Left Vertex 5
        -1.25f,  0.125f, -1.0f,   0.2f, 0.2f, 0.5f, 1.0f,   1.0f, 1.0f,   // Top Left Vertex 6
        -1.25f, -0.125f, -1.0f,   1.0f, 0.0f, 1.0f, 1.0f,   1.0f, 0.666f, // Bottom Left Vertex 7

        // 2nd rectangle (book) vertices, color values, and texture coordinates (indices 8-15)
        -0.25f,  0.375f, 0.0f,    0.0f, 0.5f, 1.0f, 1.0f,   0.0f, 0.666f, // Top Right Vertex 8
        -0.25f,  0.125f, 0.0f,    0.5f, 1.0f, 0.5f, 1.0f,   0.0f, 0.333f, // Bottom Right Vertex 9
        -1.25f,  0.125f, 0.0f,    0.5f, 0.5f, 1.0f, 1.0f,   1.0f, 0.333f, // Bottom Left Vertex 10
        -1.25f,  0.375f, 0.0f,    1.0f, 0.5f, 0.5f, 1.0f,   1.0f, 0.666f, // Top Left Vertex 11
        -0.25f,  0.125f, -1.0f,   0.2f, 0.8f, 0.5f, 1.0f,   0.0f, 0.333f, // Bottom Right Vertex 12
        -0.25f,  0.375f, -1.0f,   0.5f, 1.0f, 0.2f, 1.0f,   0.0f, 0.666f, // Top Left Vertex 13
        -1.25f,  0.375f, -1.0f,   0.2f, 0.5f, 0.8f, 1.0f,   1.0f, 0.666f, // Top Left Vertex 14
        -1.25f,  0.125f, -1.0f,   0.8f, 0.2f, 0.5f, 1.0f,   1.0f, 0.333f, // Bottom Left Vertex 15

        // 3rd rectangle (book) vertices, color values, and texture coordinates (indices 16-23)
        -0.25f,  0.625f, 0.0f,    1.0f, 0.0f, 1.0f, 1.0f,   0.0f, 0.333f, // Top Right Vertex 16
        -0.25f,  0.375f, 0.0f,    0.0f, 1.0f, 0.0f, 1.0f,   0.0f, 0.0f,   // Bottom Right Vertex 17
        -1.25f,  0.375f, 0.0f,    0.0f, 0.0f, 1.0f, 1.0f,   1.0f, 0.0f,   // Bottom Left Vertex 18
        -1.25f,  0.625f, 0.0f,    1.0f, 0.0f, 0.0f, 1.0f,   1.0f, 0.333f, // Top Left Vertex 19
        -0.25f,  0.375f, -1.0f,   0.5f, 0.5f, 1.0f, 1.0f,   0.0f, 0.0f,   // Bottom Right Vertex 20
        -0.25f,  0.625f, -1.0f,   1.0f, 1.0f, 0.5f, 1.0f,   0.0f, 0.333f, // Top Left Vertex 21
        -1.25f,  0.625f, -1.0f,   0.2f, 0.2f, 0.5f, 1.0f,   1.0f, 0.333f, // Top Left Vertex 22
        -1.25f,  0.375f, -1.0f,   1.0f, 0.0f, 1.0f, 1.0f,   1.0f, 0.0f,   // Bottom Left Vertex 23

        // Pyramid on top of 3rd rectangle (book)
        -0.75f,   1.0f, -0.5f,       1.0f, 0.0f, 1.0f, 1.0f,   0.5f, 0.5f,  // Apex Vertex 24
        -1.03125f, 0.5f, -0.78125f,  1.0f, 0.0f, 1.0f, 1.0f,   0.475f, 0.475f,  // Base - Bottom Left Vertex 25
        -0.46875f, 0.5f, -0.78125f,  1.0f, 0.0f, 1.0f, 1.0f,   0.525f, 0.475f,  // Base - Bottom Right Vertex 26
        -0.46875f, 0.5f, -0.21875f,  1.0f, 0.0f, 1.0f, 1.0f,   0.525f, 0.525f,  // Base - Top Right Vertex 27
        -1.03125f, 0.5f, -0.21875f,  1.0f, 0.0f, 1.0f, 1.0f,   0.475f, 0.525f,   // Base - Top Left Vertex 28
    };

    // Index data to share position data
    GLushort indices[] = {
        // First rectangle (book) indices (indices 0-7)
        0, 1, 3,
        1, 2, 3,
        0, 1, 4,
        0, 4, 5,
        0, 5, 6,
        0, 3, 6,
        4, 5, 6,
        4, 6, 7,
        2, 3, 6,
        2, 6, 7,
        1, 4, 7,
        1, 2, 7,

        // Second rectangle (book) indices (indices 9-15)
        8, 9, 11,
        9, 10, 11,
        8, 9, 12,
        8, 12, 13,
        8, 13, 14,
        8, 11, 14,
        12, 13, 14,
        12, 14, 15,
        10, 11, 14,
        10, 14, 15,
        9, 12, 15,
        9, 10, 15,

        // Third rectangle (book) indices (indices 16-23)
        16, 17, 19,
        17, 18, 19,
        16, 17, 20,
        16, 20, 21,
        16, 21, 22,
        16, 19, 22,
        20, 21, 22,
        20, 22, 23,
        18, 19, 22,
        18, 22, 23,
        17, 20, 23,
        17, 18, 23,

        // Pyramid on top of books indices (indices 24-28)
        24, 25, 26,
        24, 26, 27,
        24, 27, 28,
        24, 28, 25,
        25, 26, 27,
        25, 27, 28,
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerColor = 4;
    const GLuint floatsPerUV = 2;

    glGenVertexArrays(1, &mesh.vao); // We can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerColor + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerColor, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerColor)));
    glEnableVertexAttribArray(2);
}

void UCreateMeshPlane(GLMesh& mesh)
{
    // Position, Color, and Texture data
    GLfloat verts[] = {
        0.25f, -0.125f,  1.75f,  0.6f, 0.3f, 0.0f, 1.0f, 0.0f, 1.0f, // Top Right
        0.25f, -0.125f, -1.75f, 0.6f, 0.3f, 0.0f, 1.0f,  0.0f, 0.0f, // Bottom Right
        -6.25f, -0.125f, -1.75f, 0.6f, 0.3f, 0.0f, 1.0f, 1.0f, 0.0f, // Bottom Left
        -6.25f, -0.125f, 1.75f, 0.6f, 0.3f, 0.0f, 1.0f,  1.0f, 1.0f  // Top Left
    };

    // Index data to share position data
    GLushort indices[] = {
        0, 1, 2, // First triangle
        0, 2, 3 // Second triangle
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerColor = 4;
    const GLuint floatsPerUV = 2;

    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerColor + floatsPerUV);

    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerColor, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerColor)));
    glEnableVertexAttribArray(2);
}

// Function to destroy mesh objects
void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(2, mesh.vbos);
}

/*Generate and load the texture*/
bool UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}

void UDestroyTexture(GLuint textureId)
{
    glDeleteTextures(1, &textureId);
}

// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Function call creating an empty shader program object and returns the unique identifier assigned to it.
    programId = glCreateProgram();

    // Function call to create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Function call to retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // Compile the fragment shader
    // Check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);
    glLinkProgram(programId);   // Links the shader program

    // Check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Use shader program
    glUseProgram(programId);

    return true;
}

void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}
